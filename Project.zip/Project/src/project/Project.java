package project;

import java.util.Scanner;

public class Project {

    private GroceryStore store;
    private Cart cart;

    public static void main(String[] args) {
    }

    public Project(GroceryStore store) {
        this.store = store;
        cart = new Cart();
    }

    public void selectItems() {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("Enter the name of the product you want to buy"
                    + " (or 'done' to finish):");
            String input = scanner.nextLine();
            if (input.equals("done")) {
                break;
            }
            Product product = store.searchProductByName(input);
            if (product == null) {
                System.out.println("Product not found.");
                continue;
            }
            System.out.println("Enter the quantity:");
            int quantity = scanner.nextInt();
            scanner.nextLine();
            if (quantity > product.getInventoryLevel()) {
                System.out.println("Not enough inventory.");
                continue;
            }
            cart.addItem(product, quantity);
            product.setInventoryLevel(product.getInventoryLevel() - quantity);
        }
        scanner.close();
    }

    public double calculateTotalPrice() {
        double totalPrice = 0;
        for (Product product : cart.getItems().keySet()) {
            int quantity = cart.getItems().get(product);
            double price = product.getPrice();
            totalPrice += price * quantity;
        }
        return totalPrice;
    }

    public void updateInventoryLevels() {
        for (Product product : cart.getItems().keySet()) {
            int quantity = cart.getItems().get(product);
            product.setInventoryLevel(product.getInventoryLevel() - quantity);
        }
    }

}
