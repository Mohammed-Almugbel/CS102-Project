package project;

public class Product implements Discountable {

    private String name;
    private double price;
    private int inventoryLevel;

    public Product(String name, double price, int inventoryLevel) {
        this.name = name;
        this.price = price;
        this.inventoryLevel = inventoryLevel;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public int getInventoryLevel() {
        return inventoryLevel;
    }

    public void setInventoryLevel(int inventoryLevel) {
        this.inventoryLevel = inventoryLevel;
    }

    @Override
    public double calculateDiscount() {
        return 0;
    }
}
