package project;

public class Sale {

    private String customerName;
    private Cart cart;
    private double totalPrice;
    private double discount;

    public Sale(String customerName, Cart cart, double totalPrice, double discount) {
        this.customerName = customerName;
        this.cart = cart;
        this.totalPrice = totalPrice;
        this.discount = discount;
    }

    public String getCustomerName() {
        return customerName;
    }

    public Cart getCart() {
        return cart;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public double getDiscount() {
        return discount;
    }
}
